<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'order created success' => 'تم انشاء الطلب بنجاح',
    'order created success please confirm your payment gateway' => 'تم انشاء الطلب بنجاح برجاء استكمال الدفع',
];
