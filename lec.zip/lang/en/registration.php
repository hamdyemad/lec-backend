<?php

return [

    "Your Authentication Code is" => "Your Authentication Code Is ",
    "signed up successfully" => "signed up successfully",
    "auth code sent" => "auth code sent",
    "sorry couldn't send your code" => "sorry couldn't send your code, please try again",
    "incorrect code" => "incorrect code",
    "this code is expired" => "this code is expired",
    "code verified" => "code verified",
    "current password is invalid" => "current password is invalid",
    "new password can't match the old password" => "new password can't match the old password",
    "password changed successfully" => "password changed successfully",
    "you are not registered" => "you are not registered, you phone is not used",
    "Invalid Credentials" => "Invalid Credentials",
    "You are Loged In" => "You are Logged In",
    "logged out" => "Logged Out"
];